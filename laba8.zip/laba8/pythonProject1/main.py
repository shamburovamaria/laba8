from PIL import Image, ImageDraw, ImageFont

def prog1():

    filename = 'dr.jpeg'
    with Image.open(filename) as img:
        img.load()

    crop_img = img.crop((494, 166, 1571, 650))
    crop_img.save(('crop_dr.jpeg'))


def prog2():
    celebration = {'день рождения': 'dr.jpeg', 'новый год': 'newyear.jpeg', '8 марта': '8.jpeg'}

    cel = input('Для какого праздика вывести картинку?')

    f = celebration.get(cel)
    with Image.open(f) as img:
        img.load()
    img.show()


def prog3():
    img = Image.open('dr.jpeg')
    name = input('Кого хотите поздравить?')
    celebration = 'Happy birthday, ' + name + "!"
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype('/Users/wakemeupat6am/Downloads/laba8/Donpoligrafbum-Bold.otf', size=30)
    draw.text((100, 100), celebration, (0, 255, 255), font=font)
    img.save('sample.png')

prog3()